package com.example.perfectbike;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class ProfileActivity extends AppCompatActivity {

    TextView mtextview;
    ImageView imageView;
    EditText firstname,lastname;
    byte[] bytes=null;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        databaseHelper = DatabaseHelper.getDatabaseInstance(this);
        mtextview =findViewById(R.id.takephotoprofile);
        imageView = findViewById(R.id.imageview);
        firstname = findViewById(R.id.editfirstname);
        lastname = findViewById(R.id.editlastname);
        mtextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int permissioncheck = ContextCompat.checkSelfPermission(ProfileActivity.this, Manifest.permission.CAMERA);

                if(permissioncheck == PackageManager.PERMISSION_GRANTED){
                    OpenCamera();
                }
                else{
                    ActivityCompat.requestPermissions(ProfileActivity.this,new String[] {Manifest.permission.CAMERA},1);
                }
            }
        });

        Profile pf = databaseHelper.getallProfileitem();
        if(pf!=null){
            firstname.setText(pf.firstname);
            lastname.setText(pf.lastname);
            Bitmap bitmap = BitmapFactory.decodeByteArray(pf.bytes, 0, pf.bytes.length);
            imageView.setImageBitmap(bitmap);
        }
    }

    private void OpenCamera() {
        Intent intent = new Intent();
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,1);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode==1){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                OpenCamera();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode ==1 && resultCode == Activity.RESULT_OK){
            if(data!=null){
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
               // getRoundedRectBitmap(bitmap,100);
                imageView.setImageBitmap(bitmap);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                bytes = stream.toByteArray();

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void SaveName(View view) {
        String fname = firstname.getText().toString();
        String lname = lastname.getText().toString();
        if(!fname.isEmpty()&& !lname.isEmpty() && bytes!=null){
            databaseHelper.adddata(fname,lname,bytes);
        }
        else {
            Toast.makeText(this, "Fill All Values", Toast.LENGTH_SHORT).show();
        }

    }


}
