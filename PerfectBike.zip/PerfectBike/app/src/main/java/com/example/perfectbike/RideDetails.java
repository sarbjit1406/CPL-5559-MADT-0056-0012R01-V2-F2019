package com.example.perfectbike;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class RideDetails extends AppCompatActivity {

    private EditText editdistance, currentlocation, destination, calories;
    double distance,cLlat,cLlong,DLlat,DLlong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_details);
        Intent intent = getIntent();

        editdistance = findViewById(R.id.distance);
        currentlocation = findViewById(R.id.currentlocation);
        destination =  findViewById(R.id.destination);
        calories = findViewById(R.id.estimatedcalorie);

        distance = intent.getDoubleExtra("Distance",0.0);
        cLlat = intent.getDoubleExtra("CLlat",0.0);
        cLlong = intent.getDoubleExtra("CLlong",0.0);
        DLlat = intent.getDoubleExtra("DLlat",0.0);
        DLlong = intent.getDoubleExtra("DLLong",0.0);

       editdistance.setText(distance+" km");
       currentlocation.setText(cLlat + " " + cLlong);
       destination.setText(DLlat + " " + DLlong);
       calories.setText(distance*100 + "");



    }

    public void MapClick(View view) {

        Intent intent = new Intent(this,MapActivity.class);
        intent.putExtra("lat",cLlat);
        intent.putExtra("lon",cLlong);
        intent.putExtra("lat1",DLlat);
        intent.putExtra("lon1",DLlong);

        startActivity(intent);

    }
}
