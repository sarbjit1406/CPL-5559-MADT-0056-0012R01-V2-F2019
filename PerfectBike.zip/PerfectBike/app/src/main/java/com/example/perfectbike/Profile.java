package com.example.perfectbike;

public class Profile {
    public String firstname;
    public String lastname;
    public byte[] bytes;

    public Profile(String firstname, String lastname, byte[] bytes) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.bytes = bytes;
    }
}
