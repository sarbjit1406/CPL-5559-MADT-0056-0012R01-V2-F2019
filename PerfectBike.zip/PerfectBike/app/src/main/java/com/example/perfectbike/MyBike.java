package com.example.perfectbike;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

public class MyBike extends AppCompatActivity {

    ImageView imageView;
    TextView mtextview;
    EditText brand,  year;
    byte[] byteArray = null;
   private DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bike);

        imageView = findViewById(R.id.imagebike);
        mtextview = findViewById(R.id.editimage);
        brand = findViewById(R.id.brand);
        year = findViewById(R.id.year);


        mtextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int permissioncheck = ContextCompat.checkSelfPermission(MyBike.this, Manifest.permission.CAMERA);

                if(permissioncheck == PackageManager.PERMISSION_GRANTED){
                    OpenCamera();
                }
                else{
                    ActivityCompat.requestPermissions(MyBike.this,new String[] {Manifest.permission.CAMERA},1);
                }
            }
        });

        databaseHelper = DatabaseHelper.getDatabaseInstance(this);

        Bike bike = databaseHelper.getallBikeitem();
        if(bike!=null){
            brand.setText(bike.brandname);
            year.setText((bike.year));
            Bitmap bitmap = BitmapFactory.decodeByteArray(bike.image, 0, bike.image.length);
            Bitmap conv_bm  =  getCroppedBitmap(bitmap);
            imageView.setImageBitmap(conv_bm);
            bitmap.recycle();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode==1){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                OpenCamera();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode ==1 && resultCode == Activity.RESULT_OK){
            if(data!=null){
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                Bitmap conv_bm  =  getCroppedBitmap(bitmap);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                 byteArray = stream.toByteArray();
                imageView.setImageBitmap(conv_bm);
                bitmap.recycle();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void OpenCamera() {
        Intent intent = new Intent();
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,1);
    }

    public Bitmap getCroppedBitmap(Bitmap bitmap) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
                bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0,  bitmap.getWidth(), bitmap.getHeight());

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        // canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
        canvas.drawCircle(bitmap.getWidth()/2 , bitmap.getHeight()/2,
                bitmap.getWidth()/2, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        //Bitmap _bmp = Bitmap.createScaledBitmap(output, 60, 60, false);
        //return _bmp;
        return output;
    }

    public void SaveBike(View view) {
        String brnd = brand.getText().toString();
        String yr = year.getText().toString();
        if(!brnd.isEmpty()&& !yr.isEmpty()&& byteArray !=null){

            databaseHelper.addBikedata(brnd,yr,byteArray);
        }
        else{
            Toast.makeText(this, "Fill All Values", Toast.LENGTH_SHORT).show();
        }
    }
}
