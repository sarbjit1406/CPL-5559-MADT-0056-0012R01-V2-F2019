package com.example.perfectbike;

import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private  GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Intent intent = getIntent();
        double a = intent.getDoubleExtra("lat",-1.0);
        double b = intent.getDoubleExtra("lon",-1.0);
        double c = intent.getDoubleExtra("lat1",-1.0);
        double d = intent.getDoubleExtra("lon1",-1.0);
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(a, b);
        LatLng x = new LatLng(c,d);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker"));
        googleMap.addMarker(new MarkerOptions().position(x).title("MArker2"));
        mMap.addPolyline(new PolylineOptions().add(sydney,x).color(Color.BLUE).width(5));
        mMap.setMinZoomPreference(10);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }
}
