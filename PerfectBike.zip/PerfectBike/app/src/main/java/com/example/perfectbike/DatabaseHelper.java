package com.example.perfectbike;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import  android.annotation.*;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String ITEM_ID = "id";
    private static final String FIRSTNAME = "firstname";
    private static final String LASTNAME = "lastname";
    public static String TABLE_NAME_PROFILE = "mt";
    public static String PROFILE_BLOB = "PRO";
    private static final String BIKE_ITEM_ID = "Mid";
    private static final String BRAND = "firstname";
    private static final String YEAR = "lastname";
    private static final String TABLE_NAME_BIKE = "mynol";
    public static String BIKE_BLOB = "bikeimage";

    private static  DatabaseHelper databaseHelper;


    private DatabaseHelper(@NonNull Context context) {
        super(context, "MyTable", null, 1);

    }

    public static DatabaseHelper  getDatabaseInstance(Context mcontext){

        if(databaseHelper == null){
            databaseHelper = new DatabaseHelper(mcontext.getApplicationContext());
        }
        return  databaseHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String sqluse = "CREATE TABLE " + TABLE_NAME_PROFILE + " ( " +
                ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                FIRSTNAME + " TEXT, " +
                PROFILE_BLOB + " BLOB," +
                LASTNAME + " TEXT )";

        String sqluse1 = "CREATE TABLE " + TABLE_NAME_BIKE + " ( " +
                BIKE_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                BRAND + " TEXT, " +
                BIKE_BLOB + " BLOB, " +
                YEAR + " TEXT )";

        sqLiteDatabase.execSQL(sqluse);
        sqLiteDatabase.execSQL(sqluse1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public int adddata(String firstname,String lastname,byte[] bytes ) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIRSTNAME, firstname);
        values.put(LASTNAME, lastname);
        values.put(PROFILE_BLOB,bytes);
        //values.put(PROFILE_BLOB,blob);
        int id = (int) sqLiteDatabase.insert(TABLE_NAME_PROFILE, null, values);
        sqLiteDatabase.close();
        return  id;

    }

    public Profile getallProfileitem(){
        String SelectQuery= "SELECT * FROM " + TABLE_NAME_PROFILE;
        Profile profile = null ;
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(SelectQuery,null);

        while (cursor.moveToNext()){
            String fname = cursor.getString(cursor.getColumnIndex(FIRSTNAME));
            String lname = cursor.getString(cursor.getColumnIndex(LASTNAME));
            byte [] bytes = cursor.getBlob(cursor.getColumnIndex(PROFILE_BLOB));
            profile = new Profile(fname, lname,bytes);
        }
        return profile;
    }

    public Bike getallBikeitem(){
        String SelectQuery= "SELECT * FROM " + TABLE_NAME_BIKE;
        Bike profile = null ;
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(SelectQuery,null);

        while (cursor.moveToNext()){
            String fname = cursor.getString(cursor.getColumnIndex(BRAND));
            String lname = cursor.getString(cursor.getColumnIndex(YEAR));
            byte [] bytes = cursor.getBlob(cursor.getColumnIndex(BIKE_BLOB));
            profile = new Bike(fname, lname,bytes);
        }
        return profile;
    }

    public int addBikedata(String Brandtname,String year ,byte[] bytes) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(BRAND, Brandtname);
        values.put(YEAR, year);
        values.put(BIKE_BLOB,bytes);
        //values.put(PROFILE_BLOB,blob);
        int id = (int) sqLiteDatabase.insert(TABLE_NAME_BIKE, null, values);
        sqLiteDatabase.close();
        return  id;
    }
}
