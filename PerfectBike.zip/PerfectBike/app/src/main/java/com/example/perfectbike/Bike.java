package com.example.perfectbike;

import java.net.PortUnreachableException;

public class Bike {
    public String brandname ;
    public String year;
    public  byte[] image;

    public Bike(String brandname, String year, byte[] image) {
        this.brandname = brandname;
        this.year = year;
        this.image = image;
    }
}
